# Pathfinding

![icon](https://github.com/user-attachments/assets/f6632870-4744-41cf-9b9a-8a8402ec9b45)

## A simple template for pathfinding games in Godot 4.3

![Pathfinding](https://github.com/user-attachments/assets/8135909a-e02c-4d7f-b282-941a6d3c11ab)
